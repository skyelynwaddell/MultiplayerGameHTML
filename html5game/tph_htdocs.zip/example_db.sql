/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE TABLE IF NOT EXISTS `example_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_code` varchar(255) DEFAULT NULL,
  `page_id` tinytext DEFAULT NULL,
  `order_id` int(11) NOT NULL DEFAULT 0,
  `price` int(11) NOT NULL DEFAULT 3,
  `is_hidden` tinyint(1) NOT NULL DEFAULT 0,
  `amount` int(11) NOT NULL DEFAULT 1,
  `definition_id` int(11) DEFAULT NULL,
  `item_specialspriteid` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `is_package` tinyint(1) NOT NULL DEFAULT 0,
  `package_name` varchar(255) DEFAULT NULL,
  `package_description` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1351 DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `example_table` DISABLE KEYS */;
INSERT INTO `example_table` (`id`, `sale_code`, `page_id`, `order_id`, `price`, `is_hidden`, `amount`, `definition_id`, `item_specialspriteid`, `name`, `description`, `is_package`, `package_name`, `package_description`) VALUES
	(1, 'floor', '3', 1, 2, 0, 1, 249, 0, '', '', 0, NULL, NULL),
	(2, 'a0 deal102', '5', 1, 25, 0, 1, 0, 0, '', '', 1, 'Red Roller 5 Pack', '5 Red Rollers in a convenient pack'),
	(3, 'door', '6', 1, 3, 0, 1, 100, 0, 'Telephone Box', 'Dr Who?', 0, NULL, NULL),
	(4, 'petfood1', '8', 5, 1, 0, 1, 155, 0, 'Bones Mega Multipack', 'Fantastic 20% Saving!', 0, NULL, NULL),
	(5, 'petfood2', '8', 6, 1, 0, 1, 156, 0, 'Sardines Mega Multipack', 'Fantastic 20% Saving!', 0, NULL, NULL),
	(6, 'petfood4', '8', 7, 1, 0, 1, 236, 0, 'T-Bones Mega Multipack', 'Fantastic 20% Saving!', 0, NULL, NULL),
	(7, 'petfood3', '8', 8, 1, 0, 1, 157, 0, 'Cabbage Mega Multipack', 'Fantastic 20% Saving!', 0, NULL, NULL),
	(8, 'waterbowl*4', '8', 9, 2, 0, 1, 158, 0, 'Blue Water Bowl', 'Aqua unlimited', 0, NULL, NULL),
	(9, 'waterbowl*5', '8', 10, 2, 0, 1, 159, 0, 'Brown Water Bowl', 'Aqua unlimited', 0, NULL, NULL),
	(10, 'waterbowl*2', '8', 11, 2, 0, 1, 160, 0, 'Green Water Bowl', 'Aqua unlimited', 0, NULL, NULL),
	(11, 'waterbowl*1', '8', 12, 2, 0, 1, 161, 0, 'Red Water Bowl', 'Aqua unlimited', 0, NULL, NULL),
	(12, 'waterbowl*3', '8', 13, 2, 0, 1, 162, 0, 'Yellow Water Bowl', 'Aqua unlimited', 0, NULL, NULL),
	(13, 'goodie2', '8', 14, 1, 0, 1, 169, 0, 'Chocolate Mouse', 'For gourmet kittens', 0, NULL, NULL),
	(14, 'goodie1', '8', 15, 1, 0, 1, 168, 0, 'Marzipan Man', 'Crunchy Dog Treat', 0, NULL, NULL),
	(15, 'toy1', '8', 16, 2, 0, 1, 163, 0, 'Rubber Ball', 'it is bouncy-tastic', 0, NULL, NULL);
/*!40000 ALTER TABLE `example_table` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

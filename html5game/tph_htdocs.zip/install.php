<?php
    //auth data
    include ("./utility/dbconfig.php");

    //connect to database
    try {
    $conn = new PDO("mysql:host=$servername;dbname=", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully";
    } catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    }

    echo "<br><br>Connected at " . date("d-m-Y H:i:s") . "<br>";

	
    include ("./utility/dbgenerator.php");

    //close connection
    $conn = null;
?>
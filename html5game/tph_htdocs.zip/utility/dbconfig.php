<?php
    //auth data
    $servername = "localhost";
    $username = "root";
    $password = "";
    $databaseFileName = fopen("./utility/databaseName.ini", "r") or die("Unable to open file!");
    $dbname = fread($databaseFileName,filesize("./utility/databaseName.ini"));
    fclose($databaseFileName);
?>
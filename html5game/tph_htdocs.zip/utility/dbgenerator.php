<?php
    try {

        $dbnameToLoad = "example_db.sql";

        $checkDB = $conn->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$dbname'");

        $dbExists = (bool) $checkDB->fetchColumn();

        if($dbExists){
            echo "Error creating database '" . $dbname . "', this database already exists.<br>";

        } else {
            $sql = "CREATE DATABASE $dbname";
            // use exec() because no results are returned
            $conn->exec($sql);
            
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            // set the PDO error mode to exception
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $dumpDBlines = file($dbnameToLoad);
            $templine = '';
            $errors = '';

            foreach ($dumpDBlines as $line){
                // Skip it if it's a comment
                if(substr($line, 0, 2) == '--' || $line == ''){
                    continue;
                }
                
                // Add this line to the current segment
                $templine .= $line;
                
                // If it has a semicolon at the end, it's the end of the query
                if (substr(trim($line), -1, 1) == ';'){
                    // Perform the query
                    if(!$conn->query($templine)){
                        $error .= 'Error performing query "<b>' . $templine . '</b>": ' . $conn->error . '<br /><br />';
                    }
                    // Reset temp variable to empty
                    $templine = '';
                }
            }
            if(!empty($errors)){
                echo "ERROR: " . $errors;
            } else {
                echo "Database created successfully<br>";
            }
        }
    } catch(PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }

    $conn = null;
?>
<?php

    function create_database($conn, $databaseName){
        try {
            $sql = "CREATE DATABASE $databaseName";
            // use exec() because no results are returned
            $conn->exec($sql);
            echo "Database $databaseName created successfully\n";
          } catch(PDOException $e) {
            echo $sql . "\n" . $e->getMessage();
          }
    }

    function connect_database($servername, $databaseName, $username, $password){
        try {
            $databaseFileName = fopen("./utility/databaseName.ini", "w") or die("Unable to open file!");
            fwrite($databaseFileName, $databaseName);
            fclose($databaseFileName);
            echo "Connected successfully\n";
          } catch(PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
          }
    }

    function create_table($conn, $table, $columns){
        try {
            // sql to create table
            /*
            $sql = "CREATE TABLE MyGuests (
            id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            firstname VARCHAR(30) NOT NULL,
            lastname VARCHAR(30) NOT NULL,
            email VARCHAR(50),
            reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )";
            */
            
            $sql = "CREATE TABLE $table ($columns)";
          
            // use exec() because no results are returned
            $conn->exec($sql);
            echo "Table $table created successfully\n";
          } catch(PDOException $e) {
            echo $sql . "\n" . $e->getMessage();
          }
    }

    function insert_data($conn, $table, $columns, $values){
        try {
            //$sql = "INSERT INTO MyGuests (firstname, lastname, email) VALUES ('John', 'Doe', 'john@example.com')"; //example
            // Prepare the query
            $sql = "INSERT INTO $table ($columns) VALUES ($values)";
            // use exec() because no results are returned
            $conn->exec($sql);
            $last_id = $conn->lastInsertId();
            echo "New record created successfully. Last inserted ID is: " . $last_id . "\n";
        } catch(PDOException $e) {
            echo $sql . "\n" . $e->getMessage();
        }
    }

    function select_from($conn, $columns, $table){
        try {
            //$sql = "SELECT id, firstname, lastname FROM MyGuests"; //example
            // Prepare the query
            $sql = "SELECT $columns FROM $table";
            // Prepare statement
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            // set the resulting array to associative
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
            foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                echo $v . "\n";
            }
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    function select_from_where($conn, $columns, $table, $values){
        try {
            //$sql = "SELECT id, firstname, lastname FROM MyGuests WHERE lastname='Doe'"; //example
            // Prepare the query
            $sql = "SELECT $columns FROM $table WHERE $values";
            // Prepare statement
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            // set the resulting array to associative
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
            foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                echo $v . "\n";
            }
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    function select_from_orderby($conn, $columns, $table, $orderby){
        try {
            //$sql = "SELECT id, firstname, lastname FROM MyGuests ORDER BY lastname"; //example
            // Prepare the query
            $sql = "SELECT $columns FROM $table ORDER BY $orderby";
            // Prepare statement
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            // set the resulting array to associative
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
            foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                echo $v . "\n";
            }
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    function select_from_where_orderby($conn, $columns, $table, $values, $orderby){
        try {
            //$sql = "SELECT id, firstname, lastname FROM MyGuests WHERE lastname='Doe ORDER BY lastname'"; //example
            // Prepare the query
            $sql = "SELECT $columns FROM $table WHERE $values ORDER BY $orderby";
            // Prepare statement
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            // set the resulting array to associative
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
            foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                echo $v . "\n";
            }
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    function select_from_limit($conn, $columns, $table, $limit){
        try {
            //$sql = "SELECT id, firstname, lastname FROM MyGuests LIMIT 30"; //example
            // Prepare the query
            $sql = "SELECT $columns FROM $table LIMIT $limit";
            // Prepare statement
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            // set the resulting array to associative
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
            foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                echo $v . "\n";
            }
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    function select_from_where_limit($conn, $columns, $table, $values, $limit){
        try {
            //$sql = "SELECT id, firstname, lastname FROM MyGuests WHERE lastname='Doe' LIMIT 30"; //example
            // Prepare the query
            $sql = "SELECT $columns FROM $table WHERE $values LIMIT $limit";
            // Prepare statement
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            // set the resulting array to associative
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
            foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                echo $v . "\n";
            }
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    function select_from_orderby_limit($conn, $columns, $table, $orderby, $limit){
        try {
            //$sql = "SELECT id, firstname, lastname FROM MyGuests ORDER BY lastname LIMIT 30"; //example
            // Prepare the query
            $sql = "SELECT $columns FROM $table ORDER BY $orderby LIMIT $limit";
            // Prepare statement
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            // set the resulting array to associative
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
            foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                echo $v . "\n";
            }
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    function select_from_where_orderby_limit($conn, $columns, $table, $values, $orderby, $limit){
        try {
            //$sql = "SELECT id, firstname, lastname FROM MyGuests WHERE lastname='Doe ORDER BY lastname' LIMIT 30"; //example
            // Prepare the query
            $sql = "SELECT $columns FROM $table WHERE $values ORDER BY $orderby LIMIT $limit";
            // Prepare statement
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            // set the resulting array to associative
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
            foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                echo $v . "\n";
            }
        } catch(PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    function delete($conn, $table, $values){
        try {
            //$sql = "DELETE FROM MyGuests WHERE id=3"; //example
            // Prepare the query
            $sql = "DELETE FROM $table WHERE $values";
            // use exec() because no results are returned
            $conn->exec($sql);
            echo "Record deleted successfully\n";
          } catch(PDOException $e) {
            echo $sql . "<br>" . $e->getMessage();
          }
    }

    function update($conn, $table, $scope, $values){
        try {
            //$sql = "UPDATE MyGuests SET lastname='Doe' WHERE id=2"; //example
            // Prepare the query
            $sql = "UPDATE $table SET $scope WHERE $values";
            // Prepare statement
            $stmt = $conn->prepare($sql);
            // execute the query
            $stmt->execute();
            // echo a message to say the UPDATE succeeded
            echo $stmt->rowCount() . " records UPDATED successfully\n";
          } catch(PDOException $e) {
            echo $sql . "<br>" . $e->getMessage();
          }
    }

    function raw($conn, $query){
        if(strstr("$query", "CREATE DATABASE") != ""){
            try {
                $sql = "$query";
                // use exec() because no results are returned
                $conn->exec($sql);
                echo "Database created successfully\n";
              } catch(PDOException $e) {
                echo $sql . "<br>" . $e->getMessage();
              }
        } else if(strstr("$query", "CREATE TABLE") != ""){
            try {
                $sql = "$query";
                // use exec() because no results are returned
                $conn->exec($sql);
                echo "Table created successfully\n";
              } catch(PDOException $e) {
                echo $sql . "<br>" . $e->getMessage();
              }
        } else if(strstr("$query", "INSERT INTO") != ""){
            try {
                //$sql = "INSERT INTO MyGuests (firstname, lastname, email) VALUES ('John', 'Doe', 'john@example.com')"; //example
                // Prepare the query
                $sql = "$query";
                // use exec() because no results are returned
                $conn->exec($sql);
                $last_id = $conn->lastInsertId();
                echo "New record created successfully. Last inserted ID is: " . $last_id . "\n";
            } catch(PDOException $e) {
                echo $sql . "<br>" . $e->getMessage();
            }
        } else if(strstr("$query", "SELECT") != ""){
            try {
                //$sql = "SELECT id, firstname, lastname FROM MyGuests WHERE lastname='Doe ORDER BY lastname' LIMIT 30"; //example
                // Prepare the query
                $sql = "$query";
                // Prepare statement
                $stmt = $conn->prepare($sql);
                $stmt->execute();
                // set the resulting array to associative
                $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
                foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                    echo $v . "\n";
                }
            } catch(PDOException $e) {
                echo "Error: " . $e->getMessage();
            }
        } else if(strstr("$query", "DELETE") != ""){
            try {
                //$sql = "DELETE FROM MyGuests WHERE id=3"; //example
                // Prepare the query
                $sql = "$query";
                // use exec() because no results are returned
                $conn->exec($sql);
                echo "Record deleted successfully\n";
              } catch(PDOException $e) {
                echo $sql . "<br>" . $e->getMessage();
              }
        } else if(strstr("$query", "UPDATE") != ""){
            try {
                //$sql = "UPDATE MyGuests SET lastname='Doe' WHERE id=2"; //example
                // Prepare the query
                $sql = "$query";
                // Prepare statement
                $stmt = $conn->prepare($sql);
                // execute the query
                $stmt->execute();
                // echo a message to say the UPDATE succeeded
                echo $stmt->rowCount() . " records UPDATED successfully\n";
              } catch(PDOException $e) {
                echo $sql . "<br>" . $e->getMessage();
              }
        }
    }

    //class to arrange the result rows
    class TableRows extends RecursiveIteratorIterator {
        function __construct($it) {
            parent::__construct($it, self::LEAVES_ONLY);
        }
        function current() {
            return parent::current();
        }
        function beginChildren() { //edit to change the start of each result
            echo "";
        }
        function endChildren() {
            echo "\n";  //remove or edit to change the end of each result
        }
    }
?>
<?php
    //get db login credentials
    include ("./utility/dbconfig.php");

    //connect to database
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    //read data
    if(!empty($_GET['operation'])){
        $operation = $_GET['operation'];
    }
    if(!empty($_GET['table'])){
        $table = $_GET['table'];
    }
    if(!empty($_GET['scope'])){
        $scope = $_GET['scope'];
    }
    if(!empty($_GET['values'])){
        $values = $_GET['values'];
    }
    if(!empty($_GET['database'])){
        $databaseName = $_GET['database'];
    }
    if(!empty($_GET['columns'])){
        $columns = $_GET['columns'];
    }
    if(!empty($_GET['orderby'])){
        $orderby = $_GET['orderby'];
    }
    if(!empty($_GET['limit'])){
        $limit = $_GET['limit'];
    }
    if(!empty($_GET['query'])){
        $query = $_GET['query'];
    }
    
    include ("./utility/dbfunctions.php");

    if($operation == "createDB"){
        create_database($conn, $databaseName);
    } else if($operation == "connectDB"){
        connect_database($servername, $databaseName, $username, $password);
    } else if($operation == "checkDB"){
        echo $dbname . "\n";
    } else if($operation == "createTable"){
        create_table($conn, $table, $columns);
    } else if($operation == "insert"){
        insert_data($conn, $table, $columns, $values);
    } else if($operation == "select"){
        select_from($conn, $columns, $table);
    } else if($operation == "selectWhere"){
        select_from_where($conn, $columns, $table, $values);
    } else if($operation == "selectOrderby"){
        select_from_orderby($conn, $columns, $table, $orderby);
    } else if($operation == "selectWhereOrderby"){
        select_from_where_orderby($conn, $columns, $table, $values, $orderby);
    } else if($operation == "selectLimit"){
        select_from_limit($conn, $columns, $table, $limit);
    } else if($operation == "selectWhereLimit"){
        select_from_where_limit($conn, $columns, $table, $values, $limit);
    } else if($operation == "selectOrderbyLimit"){
        select_from_orderby_limit($conn, $columns, $table, $orderby, $limit);
    } else if($operation == "selectWhereOrderbyLimit"){
        select_from_where_orderby_limit($conn, $columns, $table, $values, $orderby, $limit);
    } else if($operation == "delete"){
        delete($conn, $table, $values);
    } else if($operation == "update"){
        update($conn, $table, $scope, $values);
    } else if($operation == "raw"){
        raw($conn, $query);
    }

    $conn = null;
    
?>